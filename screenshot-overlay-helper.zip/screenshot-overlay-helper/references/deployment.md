# 部署与排查

该 Skill 面向 Windows 10/11 当前用户。它不修改 Codex 或 WorkBuddy 的安装文件，而是在模型选择器旁显示独立顶置浮层。

## 前置条件

- 已安装 Codex Desktop、WorkBuddy，或两者之一。
- 可用 Python 3，并已安装 Pillow：`python -m pip install pillow`。
- 安装命令使用 PowerShell 7 (`pwsh`)；自动将截图附入输入框也需要 PowerShell 7。

安装器依次尝试指定的 `-PythonPath`、PATH 中的 `pythonw.exe` / `python.exe`，以及常见的 Conda 安装位置。运行下列命令可只安装一个平台，或指定 Python：

```powershell
pwsh -NoLogo -NoProfile -File .\scripts\Install-Screenshot-Helpers.ps1 -Target WorkBuddy
pwsh -NoLogo -NoProfile -File .\scripts\Install-Screenshot-Helpers.ps1 -PythonPath 'C:\Python312\pythonw.exe'
```

## 使用

打开目标应用并使其成为前台窗口，浮层会出现模型选择器附近。中间相机图标启动截图；右侧箭头打开设置；左侧圆点可拖动。

截图完成后，图片保存到安装目录下的 `captures` 或 `workbuddy-captures`，复制到剪贴板，并在启用默认选项时粘贴到聊天输入框。它只形成草稿。

## 常见问题

**没有显示浮层**：确认目标应用标题包含 `Codex`、`ChatGPT` 或 `WorkBuddy`，并从桌面“启动 … 截图助手”快捷方式重新启动。检查安装目录的 `overlay.log` 或 `workbuddy-overlay.log`。

**自动附图失败**：确认 PowerShell 7 可从 PATH 找到，并在目标输入框手动按 Ctrl+V。区域截图和剪贴板复制仍可使用。

**需要调整位置**：拖动浮层左侧圆点一次。选择“重置到模型栏附近”可以恢复默认位置。

**卸载**：退出两个截图助手，再删除安装目录、桌面的启动快捷方式以及开始菜单和 Startup 中的对应 `.lnk` 文件。不会影响 Codex、WorkBuddy 或用户的截图文件。
